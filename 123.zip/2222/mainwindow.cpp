#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QPainter>
#include<QPaintEvent>
#include<QPushButton>
#include<QDebug>

#include"towerposition.h"
#include"tower.h"
#include"waypoint.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    loadTowerPositions();
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::loadTowerPositions()
{
    QPoint pos[] =
    {
        QPoint(100,80),
        QPoint(400,80),
        QPoint(700,80),

        QPoint(250,360),
        QPoint(550,360),

        QPoint(920,250),
        QPoint(920,480),

        QPoint(290,670),
        QPoint(590,670),
        QPoint(890,670),

        QPoint(30,550),
        QPoint(30,780),

        QPoint(440,950),
        QPoint(740,950)
    };
    int len	= sizeof(pos) / sizeof(pos[0]);

    for (int i = 0; i < len; ++i)
        m_towerPositionsList.push_back(pos[i]);
}



void MainWindow::paintEvent(QPaintEvent *){
//    QPainter painter(this);
//    QPixmap pixmap(":/back.jpg");
//    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);
    QPixmap cachePix(":/background1.jpg");
    QPainter cachePainter(&cachePix);

    foreach (const TowerPosition &towerPos, m_towerPositionsList)
        towerPos.draw(&cachePainter);
    foreach (Tower *tower, m_towersList)
        tower->draw(&cachePainter);
    foreach (const WayPoint *wayPoint, m_wayPointsList)
        wayPoint->draw(&cachePainter);
    QPainter painter(this);
    painter.drawPixmap(0, 0, 800,800,cachePix);
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    QPoint pressPos = event->pos();
    auto it = m_towerPositionsList.begin();
    while (it != m_towerPositionsList.end())
    {
        if (canBuyTower() && it->containPoint(pressPos) && !it->hasTower())
        {
            it->setHasTower();
            Tower *tower = new Tower(it->centerPos(), this);
            m_towersList.push_back(tower);
            update();
            break;
        }

        ++it;
    }
}

bool MainWindow::canBuyTower() const
{
    return true;
}

void MainWindow::addWayPoints()
{
    WayPoint *wayPoint1 = new WayPoint(QPoint(0,200));
    m_wayPointsList.push_back(wayPoint1);

    WayPoint *wayPoint2 = new WayPoint(QPoint(800,200));
    m_wayPointsList.push_back(wayPoint2);
    wayPoint2->setNextWayPoint(wayPoint1);

    WayPoint *wayPoint3 = new WayPoint(QPoint(800,550));
    m_wayPointsList.push_back(wayPoint3);
    wayPoint3->setNextWayPoint(wayPoint2);

    WayPoint *wayPoint4 = new WayPoint(QPoint(200,550));
    m_wayPointsList.push_back(wayPoint4);
    wayPoint4->setNextWayPoint(wayPoint3);

    WayPoint *wayPoint5 = new WayPoint(QPoint(200,900));
    m_wayPointsList.push_back(wayPoint5);
    wayPoint5->setNextWayPoint(wayPoint4);

    WayPoint *wayPoint6 = new WayPoint(QPoint(1000,900));
    m_wayPointsList.push_back(wayPoint6);
    wayPoint6->setNextWayPoint(wayPoint5);
}






