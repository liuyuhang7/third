#include "enemy.h"

Enemy::Enemy(QObject *parent) : QObject(parent)
{

}
