#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include"towerposition.h"
#include"tower.h"
#include"waypoint.h"
#include <QMainWindow>
#include <QPixmap>
#include <QPainter>
#include<QPaintEvent>
#include<QPushButton>

QT_BEGIN_NAMESPACE

namespace Ui {
class MainWindow;
}

QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent=nullptr);
    ~MainWindow();
protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);

private:
    Ui::MainWindow *ui;
    QList<TowerPosition> m_towerPositionsList;
    QList<Tower *> m_towersList;
    QList<WayPoint *> m_wayPointsList;
    void loadTowerPositions();//可以放塔的位置
    bool canBuyTower() const;//买塔
    void addWayPoints();//航点

};

#endif // MAINWINDOW_H
